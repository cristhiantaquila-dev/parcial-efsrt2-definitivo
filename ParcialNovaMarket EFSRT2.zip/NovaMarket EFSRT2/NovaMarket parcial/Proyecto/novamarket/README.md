# NovaMarket

Sistema web académico de gestión de ventas e inventario, desarrollado con Java 17 y Spring Boot.

## Funciones del prototipo
- Listar y registrar productos.
- Eliminar productos.
- Registrar ventas.
- Calcular el total automáticamente.
- Descontar del inventario las unidades vendidas.
- Consultar el historial de ventas.
- Validar precio, stock y cantidad.

## Requisitos
- JDK 17 o superior.
- Maven 3.6 o superior.
- Visual Studio Code (recomendado: extensiones Extension Pack for Java y Spring Boot Extension Pack).

## Ejecutar
1. Descomprime el proyecto.
2. Abre en VS Code la carpeta que contiene `pom.xml`.
3. Abre Terminal > New Terminal.
4. Ejecuta: `mvn spring-boot:run`
5. Espera el mensaje `Started NovaMarketApplication`.
6. Abre `http://localhost:8080`.

La base H2 se guarda localmente en la carpeta `data`.

## Endpoints principales
- `GET /api/productos`
- `POST /api/productos`
- `PUT /api/productos/{id}`
- `DELETE /api/productos/{id}`
- `GET /api/ventas`
- `POST /api/ventas`

Consola H2 para desarrollo: `http://localhost:8080/h2-console`
JDBC URL: `jdbc:h2:file:./data/novamarketdb`
Usuario: `sa`
Contraseña: dejar vacía.

## Arquitectura de tres capas
- Vista: `src/main/resources/static/index.html`
- Negocio: paquetes `service`
- Datos: paquetes `model` y `repository`, con base H2.

## Nota de seguridad
Es un prototipo académico local. Para producción se debe añadir autenticación y autorización, HTTPS, gestión segura de credenciales, copias de seguridad y desactivar la consola H2.
