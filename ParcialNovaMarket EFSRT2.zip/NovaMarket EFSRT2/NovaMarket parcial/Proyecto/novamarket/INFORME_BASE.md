# Informe técnico parcial: NovaMarket

## 1. Descripción de la organización
NovaMarket es una empresa comercial ficticia dedicada a la venta minorista de productos de consumo diario.

## 2. Situación problemática
El registro manual de productos y ventas puede ocasionar errores en los precios, diferencias en el inventario, demoras para consultar existencias y dificultad para revisar las ventas realizadas. Se propone centralizar estas operaciones en un sistema web.

## 3. Objetivo
Desarrollar un prototipo web que permita administrar productos, registrar ventas y actualizar automáticamente el stock mediante una arquitectura de tres capas.

## 4. Requisitos funcionales
- RF01: El sistema permitirá registrar productos con nombre, precio y stock.
- RF02: El sistema permitirá listar los productos registrados.
- RF03: El sistema permitirá eliminar productos.
- RF04: El sistema permitirá registrar una venta indicando producto y cantidad.
- RF05: El sistema calculará el total de la venta.
- RF06: El sistema descontará del stock la cantidad vendida.
- RF07: El sistema impedirá ventas con stock insuficiente.
- RF08: El sistema mostrará el historial de ventas.

## 5. Requisitos no funcionales
- RNF01: La interfaz será accesible desde un navegador web.
- RNF02: La aplicación validará los datos ingresados.
- RNF03: La información se almacenará en una base de datos relacional H2.
- RNF04: El código estará organizado en capas para facilitar mantenimiento.
- RNF05: El prototipo responderá en un entorno local de desarrollo.

## 6. Arquitectura propuesta
Se utilizará una arquitectura de tres capas:
1. Vista: página HTML, CSS y JavaScript que presenta formularios y tablas.
2. Negocio: servicios Java que contienen las reglas para registrar productos y ventas, calcular importes y controlar stock.
3. Datos: entidades JPA y repositorios Spring Data JPA que realizan las operaciones sobre H2.

Flujo: Usuario → Vista web → Controlador REST → Servicio → Repositorio → Base de datos H2.

## 7. Tecnologías
- Java 17: lenguaje de programación.
- Spring Boot: creación y configuración de la aplicación.
- Spring Web: servicios REST.
- Spring Data JPA: persistencia y acceso a datos.
- H2: base de datos relacional local.
- HTML, CSS y JavaScript: interfaz web.
- Maven: gestión de dependencias y ejecución.

## 8. Seguridad
Se aplican validaciones para evitar nombres vacíos, precios no positivos, stock negativo y cantidades de venta menores que uno. La operación de venta se ejecuta dentro de una transacción y verifica la disponibilidad antes de descontar existencias. El acceso a datos se realiza mediante JPA. La consola H2 está habilitada únicamente para desarrollo local y debe deshabilitarse en producción. Para una versión final se recomienda implementar inicio de sesión, roles, HTTPS y copias de seguridad.

## 9. Conclusiones preliminares
El prototipo integra las capas de vista, negocio y datos. Permite administrar productos y registrar ventas, aplicando reglas básicas de inventario. La separación por capas facilita realizar cambios y ampliar el sistema.

## 10. Recomendaciones
Incorporar edición de productos, gestión de usuarios y roles, reportes por fechas, registro de clientes, comprobantes y pruebas automatizadas antes de una puesta en producción.
