package com.novamarket.service;

import com.novamarket.dto.VentaRequest;
import com.novamarket.dto.VentaResponse;
import com.novamarket.model.Producto;
import com.novamarket.model.Venta;
import com.novamarket.repository.ProductoRepository;
import com.novamarket.repository.VentaRepository;
import java.math.BigDecimal;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

@Service
public class VentaService {
    private final ProductoRepository productoRepository;
    private final VentaRepository ventaRepository;

    public VentaService(ProductoRepository productoRepository, VentaRepository ventaRepository) {
        this.productoRepository = productoRepository;
        this.ventaRepository = ventaRepository;
    }

    public List<VentaResponse> listar() {
        return ventaRepository.findAllByOrderByFechaDesc().stream()
            .map(this::convertir)
            .toList();
    }

    @Transactional
    public VentaResponse registrar(VentaRequest request) {
        Producto producto = productoRepository.findById(request.getProductoId())
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Producto no encontrado"));

        if (producto.getStock() < request.getCantidad()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Stock insuficiente para completar la venta");
        }

        producto.setStock(producto.getStock() - request.getCantidad());
        productoRepository.save(producto);

        BigDecimal total = producto.getPrecio().multiply(BigDecimal.valueOf(request.getCantidad()));
        Venta venta = ventaRepository.save(new Venta(producto, request.getCantidad(), total));
        return convertir(venta);
    }

    private VentaResponse convertir(Venta venta) {
        return new VentaResponse(
            venta.getId(),
            venta.getProducto().getNombre(),
            venta.getCantidad(),
            venta.getTotal(),
            venta.getFecha()
        );
    }
}
