package com.novamarket.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public record VentaResponse(
    Long id,
    String producto,
    Integer cantidad,
    BigDecimal total,
    LocalDateTime fecha
) {}
