package com.novamarket;

import com.novamarket.model.Producto;
import com.novamarket.repository.ProductoRepository;
import java.math.BigDecimal;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class NovaMarketApplication {
    public static void main(String[] args) {
        SpringApplication.run(NovaMarketApplication.class, args);
    }

    @Bean
    CommandLineRunner cargarDatosIniciales(ProductoRepository repository) {
        return args -> {
            if (repository.count() == 0) {
                repository.save(new Producto("Arroz 1 kg", new BigDecimal("4.50"), 30));
                repository.save(new Producto("Azúcar 1 kg", new BigDecimal("4.20"), 25));
                repository.save(new Producto("Aceite 1 L", new BigDecimal("8.90"), 18));
                repository.save(new Producto("Leche evaporada", new BigDecimal("4.30"), 40));
                repository.save(new Producto("Fideos 500 g", new BigDecimal("3.20"), 35));
            }
        };
    }
}
